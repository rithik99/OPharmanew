function oyy(pic,price,detail){
var newWindow = window.open('incc.html', 'formUntukUpdate', 'width=1000,height=700');
newWindow.onload = function(){
	price = "Rs." + price;
   // newWindow.document.getElementById('').value = h;
    newWindow.document.getElementById('labid').innerText = detail;
    newWindow.document.getElementById('priceid').innerText = price;
    newWindow.document.getElementById('picid').src=pic;
};}

function cart(detail,price){
	var str1 = "Confirm to Add the item '"+detail+"'' of "+"Rs. "+price+" into the cart ? ";
	var h = confirm(/*"Confirm to Add the item '+detail+'' of "+"Rs. +price+ into the cart ? "*/str1);
	if(h == true){
		document.orderform.order.value=detail;
		document.orderform.ordercost.value=price;
		document.getElementById("orderfrm").submit();
	}
}

function cart1(x,y){
	//var a = document.getElementById('labid').value;
	//var b = document.getElementById('priceid').value;
	var str1 = "Confirm to Add the item '"+x+"'' of "+"Rs. "+y+" into the cart ? ";
	var h = confirm(/*"Confirm to Add the item '+detail+'' of "+"Rs. +price+ into the cart ? "*/str1);
	if(h == true){
		alert("SuccesFully Added");
	}
}

function changimg(pic){
	document.getElementById('imgg').src=pic;
}

function openanim(){
	document.getElementById('card').style.display="none";
	document.getElementById('anim').style.display="block";
}
function opencard(){
	document.getElementById('card').style.display="block";
	document.getElementById('anim').style.display="none";
}
function showall(){
	document.getElementById('card').style.display="block";
	document.getElementById('anim').style.display="block";
}